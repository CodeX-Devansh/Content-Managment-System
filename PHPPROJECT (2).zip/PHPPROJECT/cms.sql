-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2023 at 10:20 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(16) NOT NULL,
  `username` varchar(32) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `hashed_password`) VALUES
(1, 'satvik', '$2y$10$b8MGSe3ZeXAUOulHWjQfQ.1ALuB7N3i5B.NnLpyOM1iSkPKUo8872'),
(54, 'ishan', '$2y$10$3g3agzOmOshzYN5gYT/CsOSb4XCLh48Wl.txkcEjpxkyky9TAKYXG'),
(73, 'yagyam', '$2y$10$LRWliAW08Q1UsoPFEC4SweJOW2omM57mE1geJLL0n4GcwPZ2tbs4u'),
(74, 'random', '$2y$10$czhdeGrJ5tBVQhbVaqQEEe/aziu00rGVes12CIZIXU/lAY4qo5//i'),
(75, 'rajat', '$2y$10$dXE27/dTzPuBKx0rMXn7PeNbuLFVVxj7DiR4h8ExoaZ7y306P6ieS'),
(76, 'new', '$2a$12$ES5Ui41zeSfzoVOkqTC3yeN4J/pIzjVoSy6kCib4tvMdbIyZ9mvyi');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(16) NOT NULL,
  `subject_id` int(16) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `position` int(16) DEFAULT NULL,
  `visible` varchar(16) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `subject_id`, `menu_name`, `position`, `visible`, `content`) VALUES
(51, 39, 'Large Widgets', 1, 'yes', 'Lets see'),
(52, 39, 'Small Widgets', 2, 'yes', 'These are small widgets'),
(54, 40, 'Certification', 1, 'yes', 'hello.....'),
(62, 42, 'sda', 1, 'yes', ''),
(63, 55, 'Introduction', 1, 'yes', 'C++ is very popular object-oriented programming \r\nlanguage.\r\n'),
(64, 55, 'if-else', 2, 'yes', 'if (condition)\r\n    stmt;\r\nelse\r\n    stmt;'),
(65, 40, 'New page', 2, 'no', 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(16) NOT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `position` int(16) DEFAULT NULL,
  `visible` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `menu_name`, `position`, `visible`) VALUES
(39, 'Products', 1, 'yes'),
(40, 'Services', 2, 'yes'),
(42, 'Today\'s Widget Trivia', 3, 'yes'),
(54, 'Temp2', 4, 'yes'),
(55, 'C++', 5, 'yes');

--
-- Triggers `subjects`
--
DELIMITER $$
CREATE TRIGGER `delete_pages` BEFORE DELETE ON `subjects` FOR EACH ROW delete from pages where pages.subject_id = old.id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_pages` AFTER UPDATE ON `subjects` FOR EACH ROW update pages set pages.subject_id = new.id where pages.subject_id=old.id
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
